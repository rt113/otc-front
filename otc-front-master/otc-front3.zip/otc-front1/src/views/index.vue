<template>
  <div class="hello"> 
    <demo1></demo1>

    <keep-alive>
      <router-view></router-view>
    </keep-alive> 
  </div>
</template>

<script>
 import demo1 from "../components/demo3";


import axios from 'axios'
export default {

  components: {
  demo1
  },
  data() {
    return {
    
      
    };
  },

  methods: {
 
  },


};
</script>


<style >

</style>
