<template>
  <div id="app">

    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
 /* 翻译过来就是，假设有一段文字，每个字符按照 Arial、Helvetica、无衬线字体、宋体的顺序来渲染。 */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;    
  /* 文字清晰 */
  text-align: center; 
  /* text-align 属性规定HTML元素中的文本的水平对齐方式。 */
  color: #000000 gray;
/* background-color: green; */
  margin-top: 60px;
}
/* .body {
  position: absolute;
  left: 240px;
  right: 20px;
  bottom: 20px;
  top: 360px;
  background-color: pink;
} */
</style>
