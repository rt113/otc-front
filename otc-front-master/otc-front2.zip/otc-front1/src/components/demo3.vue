<template>
    <div class="hello">

        <el-button type="primary" @click="dialogFormVisible = true" style="text-align:left">修改需求</el-button>

        <el-dialog title="变更申请" :visible.sync="dialogFormVisible" style="text-align:left" width="70%">

            <!--  -->

            <el-form :inline="true" :model="formInline" class="demo-form-inline" style="text-align:left">

                <el-col :span="12">所属合同
                    <el-input v-model="pact" placeholder=" " size="mini" disabled="true" style="width:70%"></el-input>
                </el-col>
                <!-- <el-col :span="4">所属项目：<input v-model="answer2"></el-col> -->
                <el-col :span="6">所属项目
                    <el-input v-model="item" placeholder=" OTC研发项目" disabled="true" style="width:50%" size="mini">
                    </el-input>
                </el-col>

                <el-cascader :options="options2" v-model="time" @change="handleChange2" placeholder="本期" size="mini" style="width:10%"></el-cascader>

                <p></p>
                <el-col :span="12">
                    需求来源
                    <el-cascader :options="options4" v-model="sourcedemand" @change="handleChange4" placeholder="市场" size="mini" style="width:70%"></el-cascader>&nbsp</el-col>

                <el-col :span="11">来源备注
                    <el-input v-model="sourcenote" placeholder=" 咨询公司提出" style="width:70%" size="mini">
                    </el-input>
                </el-col>

                <br></br>
                <p></p>
                <el-col :span="12">
                    &nbsp&nbsp&nbsp优先级
                    <el-cascader :options="options5" v-model="priority" @change="handleChange5" placeholder="重要不紧急" size="mini" style="width:70%"></el-cascader>
                </el-col>
                <p></p>
                <br></br>
                <p></p>
                <el-col :span="12">需求名称
                    <el-input v-model="demandname" placeholder="考核模块开发需求 " size="mini" disabled="true" style="width:70%"></el-input>
                </el-col>
                <el-col :span="11">计划工时
                    <el-input v-model="planetime" placeholder=" " size="mini" style="width:70%"></el-input>
                </el-col>
                <p></p><br></br>
                <p></p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 附件
                <el-button @click="handleClick8" size="small" position="left">+点击上传</el-button>
                不超过50M

                </br>

                <p>

                    影响范围
                    <el-button v-on:click="handleClick1('primary','','','')" v-bind:type="v1" plain size="small">需求</el-button>
                    <el-button v-on:click="handleClick2('','primary','','')" v-bind:type="v2" plain size="small">验收</el-button>
                    <el-button v-on:click="handleClick3('','','primary','')" v-bind:type="v3" size="small">合同</el-button>
                    <el-button v-on:click="handleClick4('','','','primary')" v-bind:type="v4" size="small">沟通</el-button>
                </p>

                <div class="show1" v-show="show1">
                    <form :class="change" disabled="true">具体影响
                        <input type="radio" name="influence" value="yes">需求增加
                        <input type="radio" name="influence" value="no">需求减少</form>
                </div>
                <div class="show2" v-show="show2">
                    <form :class="change" disabled="true">具体影响
                        <input type="radio" name="influence" value="yes">影响验收
                        <input type="radio" name="influence" value="no">不影响验收</form>
                </div>
                <div class="show3" v-show="show3">
                    <form :class="change" disabled="true">具体影响
                        <input type="radio" name="influence" value="yes">影响合同
                        <input type="radio" name="influence" value="no">不影响合同</form>
                </div>
                <div class="show4" v-show="show4">
                    <form :class="change" disabled="true">具体影响
                        <input type="radio" name="influence" value="yes">已充分沟通
                        <input type="radio" name="influence" value="no">未充分沟通</form>
                </div>

                </p>
                &nbsp&nbsp 评审组
                <el-cascader :options="options3" v-model="reviewgroup" @change="handleChange3" placeholder="请选择" v-bind:disabled="input1" size="mini" style="width:60%"></el-cascader>

                <!-- <el-col ><input v-model="answer3" placeholder=" OTC研发项目" disabled="input1"> -->
                <label for="label" @change="clickMe">
                    <input type="checkbox" id="label" v-model="ckeckVal" size="medium">需要评审
                </label>
                </el-col>
                <p></p>
                </form>
                <!-- <p :class="ckeckClass">{{ckeckInfo}}</p>  -->
                </p>
                <el-col :span="22">
                    &nbsp&nbsp 抄送组

                    <el-cascader :options="options1" v-model="selectedOptions1" @change="handleChange1" size="mini" style="width:90%"></el-cascader>
                </el-col>

           <p></p><br></br><br></br>

            <div > 
                  <form> 
                 需求描述<editor ref="editorOne" v-model="detail" @change="change"style="top:-100px;width:85%"></editor></form>
            </div>
            <p></p><br></br>
            <div>

                验收标准
                <editor ref="editorTwo" v-model="detail" @change="change" style="width:70%"></editor>
            </div>

            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false" style="text-align:left">取 消</el-button>
                <el-button type="primary" @click="dialogFormVisible = false" style="text-align:right">确 定</el-button>
                </p>
            </div>
        </el-dialog>
        </el-form>
    </div>
</template>

<script>
import Editor from '@/components/wangEditor'
export default {
    name: 'demo2',
    components: { Editor },
    data() {
        return {
             detail: "",
            dialogFormVisible: false,
            form: {
                name: '',
                region: '',
                date1: '',
                date2: '',
                delivery: false,
                type: [],
                resource: '',
                desc: ''

            },
            formLabelWidth: '240px',
            pact: '    ',
            item: 'OTC研发项目',
            input1: true,
            c1: '需求增加',
            s1: '需求减少',
            v1: 'primary',
            show1: false,
            show2: false,
            show3: false,
            show4: false,
            // msg: 'Welcome to Your Vue.js App',
            ckeckVal: false,
            ckeckClass: '',
            ckeckInfo: '复选框没有被选中',

            options1: [
                {
                    value: '1',
                    label: 'components',
                    children: [{
                        value: '1',
                        label: 'input'
                    },
                    {
                        value: '2',
                        label: 'swipper'
                    }]

                },
                {
                    value: '2',
                    label: 'views'
                },
                {
                    value: '3',
                    label: 'actions'
                }
            ],




            options2: [
                {
                    value: '2',
                    label: '本期'
                },
                {
                    value: '1',
                    label: '往年',
                    children: [{
                        value: '1',
                        label: '去年'
                    },
                    {
                        value: '2',
                        label: '前年'
                    }]
                },
            ],
            options3: [
                {
                    value: '1',
                    label: '别人审评',
                    children: [{
                        value: '1',
                        label: '1组'
                    },
                    {
                        value: '2',
                        label: '2组'
                    }]

                },
                {
                    value: '2',
                    label: '自己审评'
                },
                {
                    value: '3',
                    label: '直接通过'
                }
            ],




        }
    },




    methods: {
        change(val) {
            console.log(val)
        },
        handleClick1: function(v1, v2, v3, v4) {
            this.show1 = true,
                this.show2 = false,
                this.show3 = false,
                this.show4 = false,
                this.v1 = v1; this.v2 = v2; this.v3 = v3; this.v4 = v4;
        },
        handleClick2: function(v1, v2, v3, v4) {
            this.show1 = false,
                this.show2 = true,
                this.show3 = false,
                this.show4 = false,
                this.v2 = v2; this.v1 = v1; this.v3 = v3; this.v4 = v4;
        },
        handleClick3: function(v1, v2, v3, v4) {
            this.show1 = false,
                this.show2 = false,
                this.show3 = true,
                this.show4 = false,
                this.v3 = v3; this.v1 = v1; this.v2 = v2; this.v4 = v4;
        },
        handleClick4: function(v1, v2, v3, v4) {
            this.show1 = false,
                this.show2 = false,
                this.show3 = false,
                this.show4 = true,
                this.v4 = v4; this.v1 = v1; this.v2 = v2; this.v3 = v3;
        },

        clickMe() {
            var that = this;
            if (that.ckeckVal) {
                that.ckeckInfo = '复选框被选中了';
                that.input1 = false;
                // that.c1='666';
            } else {
                that.ckeckInfo = '复选框没有被选中';
                that.input1 = true;

                that.reviewgroup = '请选择';

            }
        },
        handleClick8() {
            this.$router.replace('/hoo1')
        }
        // submit() {
        //     input1 == !input1
        // }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1,
h2 {
    font-weight: normal;
}

ul {
    list-style-type: none;
    padding: 0;
}

li {
    display: inline-block;
    margin: 0 10px;
}

a {
    color: #42b983;
}
</style>
