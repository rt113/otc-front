import Mock from 'mockjs';

// Mock.mock('/connect',{
//   'name':'@CNAME',
//   'email':'@EMAIL',
  

// });

// let demoList = {
//   status: 200,
//   message: 'success',
//   data: {
//     total: 100,
//     'rows|10': [{
//       id: '@guid',
//       name: '@cname',
//       'age|20-30': 23,
//       'job|1': ['前端工程师', '后端工程师', 'UI工程师', '需求工程师']
//     }]
//   }
// };

// export default {
//     'get|/parameter/query': demoList
// }


 //      address:"@city",
          //  data:"@date",
          //  email:"@email",
          //  name :"cname",
          //  phone:"@number",
          //  id:"@ID",
//    province:"@province",

const {newList2}=Mock.mock({
  'newList2|15-20':
    [{
      city: '@city',
      area: '@county(true)',
      id: '@zip',
      name: "@cname",
     phone: '@zip()',
      manager: '@last',
      a1:"",
      a2:"",
      a3:"",
      a4:"",
    },
    
  ]
})


Mock.mock('/connect','get',()=>{
  return {
    status:200,
    list:newList2,
    total:newList2.length
  }
})
console.log(newList2)