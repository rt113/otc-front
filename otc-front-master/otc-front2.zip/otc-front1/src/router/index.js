import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/views/Index'
 import Hoo1 from '@/views/Hoo1'
// import Hoo2 from '@/views/Hoo2'
// import Hoo3 from '@/views/Hoo3'
// import Hoo4 from '@/views/Hoo4'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    name: 'Index',
    component: Index,},
    { path:'/hoo1',
    name:'Hoo1',
    component:Hoo1
    // children: [
    //   {
    //     path: '/',
    //     name: 'Hoo1',
    //     component: Hoo1,
    //   }, {
    //     path: '/hoo2',
    //     name: 'Hoo2',
    //     component: Hoo2,
    //   }, {
    //     path: '/hoo3',
    //     name: 'Hoo3',
    //     component: Hoo3,
    //   }, {
    //     path: '/hoo4',
    //     name: 'Hoo4',
    //     component: Hoo4,
    //   }],
 
  }]
})

const VueRouterPush = Router.prototype.push
Router.prototype.push = function push(to) {
  return VueRouterPush.call(this, to).catch(err => err)
}
